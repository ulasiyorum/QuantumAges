namespace Consts
{
    public enum ResourceType
    {
        GreenCrystal = 10,
        BlueCrystal = 35
    }
}