namespace Consts
{
    public enum UnitTeam
    {
        Green,
        Red
    }
}