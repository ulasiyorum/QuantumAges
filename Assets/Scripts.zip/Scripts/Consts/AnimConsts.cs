namespace Consts
{
    public enum AnimConsts
    {
        idle = 0,
        move = 1,
        attack = 2,
        die = 3
    }
}