namespace Consts
{
    public enum SoldierEnum
    {
        Robot = 0,
        Shooter = 1,
        SuperSoldier = 2
    }
}