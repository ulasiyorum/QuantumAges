namespace Consts
{
    public static class ApiConsts
    {
        public const string RandomUserApiUrl = "https://api.api-ninjas.com/v1/randomuser";
        public const string X_API_KEY = "6pkiuGzfUB5+kJ+7mzSoNQ==545FzjjGO8lzenYI";
    }
}