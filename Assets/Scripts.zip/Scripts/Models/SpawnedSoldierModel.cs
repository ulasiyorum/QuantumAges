using UnityEngine;

namespace Models
{
    public class SpawnedSoldierModel
    {
        public GameObject spawnedSoldier;
        public UnitManager unitManager;
    }
}