using System;

namespace Models
{
    public class RandomUserResponseModel
    {
        public string username;
    }
}